package com.xpertern;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcommerceWepAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcommerceWepAppApplication.class, args);
	}

}
