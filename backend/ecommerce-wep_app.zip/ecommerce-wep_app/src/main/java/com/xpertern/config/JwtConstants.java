package com.xpertern.config;

public class JwtConstants {
	public static final String SECRET_KEY = "kjgkljgklgj knkaengjnkklsgjngklgthtrhrthrth";
	public static final String JWT_HEADER = "Authorization";
}
